<?php get_header(); $uri = get_template_directory_uri(); ?>
<a class="skip" href="#main">تخطَّ إلى المحتوى</a>

<!-- INTRO SPLASH -->
<div class="intro-splash" id="intro-splash" role="presentation">
    <div class="intro-symbol">
        <span class="valve-mark" style="background-image:url('<?php echo $uri; ?>/assets/brand-sign.jpeg')"></span>
    </div>
    <div class="intro-brand">
        <strong>مجموعة حريتاني</strong>
        <span>HRITANI GROUP</span>
    </div>
    <div class="intro-progress"></div>
</div>

<main id="main">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <article class="page-intro">
        <div class="container">
            <h1><?php the_title(); ?></h1>
            <p><?php echo esc_html(get_the_excerpt()); ?></p>
        </div>
    </article>
    <div class="container section">
        <div class="detail-grid">
            <div><?php the_content(); ?></div>
            <aside class="request-panel">
                <h2>اطلب عرض سعر</h2>
                <p>أخبرنا بمتطلبات مشروعك وسنرسل لك عرضاً مفصلاً.</p>
                <a class="button" href="tel:+963944044252">اتصل الآن</a>
                <small>أو راسلنا: info@neumaticworld.com</small>
            </aside>
        </div>
    </div>
    <?php endwhile; endif; ?>
</main>

<?php get_footer(); ?>