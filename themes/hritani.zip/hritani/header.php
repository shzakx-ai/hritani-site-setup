<?php if (!defined('ABSPATH')) exit; $uri = get_template_directory_uri(); ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> dir="rtl">
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- TOPBAR -->
<div class="topbar">
    <div class="container">
        <span>تجهيزات صناعية متكاملة — منذ 1985</span>
        <a href="tel:+963944044252">اتصل الآن <span>+963 944 044 252</span></a>
    </div>
</div>

<header>
    <div class="container nav">
        <a class="brand" href="<?php echo home_url('/'); ?>">
            <span class="brand-symbol valve-mark" style="background-image:url('<?php echo $uri; ?>/assets/brand-sign.jpeg')"></span>
            <span class="brand-wordmark">
                <strong>عالم البخار</strong>
                <small>HRITANI GROUP</small>
            </span>
        </a>
        <nav aria-label="القائمة الرئيسية">
            <?php hritani_nav(); ?>
        </nav>
        <a class="header-contact" href="tel:+963944044252">+963 944 044 252</a>
        <button class="menu-toggle" aria-label="فتح القائمة" aria-expanded="false">☰</button>
    </div>
</header>