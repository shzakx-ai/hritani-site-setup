<?php if (!defined('ABSPATH')) exit; $uri = get_template_directory_uri(); ?>

<footer>
    <div class="container">
        <div class="footer-grid">
            <div>
                <a class="brand" href="<?php echo home_url('/'); ?>">
                    <span class="brand-symbol valve-mark" style="background-image:url('<?php echo $uri; ?>/assets/brand-sign.jpeg')"></span>
                    <span class="brand-wordmark">
                        <strong>عالم البخار</strong>
                        <small>HRITANI GROUP</small>
                    </span>
                </a>
                <p>تجهيزات متكاملة لخطوط البخار والمعامل الغذائية والدوائية. خبرة صناعية تمتد لسنوات في التجهيزات الصناعية والتحكم.</p>
            </div>
            <div>
                <h3>روابط سريعة</h3>
                <a href="#products">منتجاتنا</a>
                <a href="#categories">تصنيفاتنا</a>
                <a href="#about">من نحن</a>
                <a href="#contact">تواصل معنا</a>
            </div>
            <div>
                <h3>التصنيفات</h3>
                <a href="#products">الصمامات الصناعية</a>
                <a href="#products">أنابيب وخطوط البخار</a>
                <a href="#products">الوصلات والملحقات</a>
                <a href="#products">تجهيزات الستانلس ستيل</a>
            </div>
            <div>
                <h3>تواصل معنا</h3>
                <a href="tel:+963944044252">+963 944 044 252</a>
                <a href="mailto:info@neumaticworld.com">info@neumaticworld.com</a>
                <a href="#">سوريا — حلب، السليمانية، شارع الحاج حبيب</a>
            </div>
        </div>
        <div class="footer-bottom">
            <span>© <?php echo date('Y'); ?> مجموعة حريتاني — جميع الحقوق محفوظة</span>
            <span dir="ltr">HRITANI GROUP · STEAM SOLUTIONS</span>
        </div>
    </div>
</footer>

<!-- Mobile menu -->
<script>
(function(){
    var t = document.querySelector('.menu-toggle');
    if (!t) return;
    var n = document.querySelector('.nav nav');
    t.addEventListener('click', function(){
        var open = n.classList.toggle('open');
        t.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
})();
</script>
<!-- Intro splash hides after animation -->
<script>
var s = document.getElementById('intro-splash');
if (s) { setTimeout(function(){ s.style.display='none'; }, 2400); }
</script>

<?php wp_footer(); ?>
</body>
</html>