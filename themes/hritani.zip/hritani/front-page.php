<?php get_header(); $uri = get_template_directory_uri(); ?>
<a class="skip" href="#main">تخطَّ إلى المحتوى</a>

<!-- INTRO SPLASH -->
<div class="intro-splash" id="intro-splash" role="presentation">
    <div class="intro-symbol">
        <span class="valve-mark" style="background-image:url('<?php echo $uri; ?>/assets/brand-sign.jpeg')"></span>
    </div>
    <div class="intro-brand">
        <strong>مجموعة حريتاني</strong>
        <span>HRITANI GROUP</span>
    </div>
    <div class="intro-progress"></div>
</div>

<main id="main">

<!-- HERO -->
<section class="hero reference-hero">
    <img class="hero-photo" src="<?php echo $uri; ?>/assets/steam-hero.png" alt="خطوط البخار والتجهيزات الصناعية">
    <div class="hero-shade"></div>
    <div class="container hero-content">
        <div class="hero-copy">
            <h1>تجهيزات متكاملة.<br><em>تقود الصناعة.</em></h1>
            <p>خطوط البخار • المعامل الغذائية والدوائية • الصمامات والوصلات</p>
        </div>
        <form class="hero-search" role="search" action="<?php echo home_url('/'); ?>" method="get">
            <input type="search" name="s" placeholder="ابحث في منتجاتنا…">
            <button type="submit">بحث</button>
        </form>
    </div>
</section>

<!-- FEATURED PRODUCTS (6 + 2 إضافية) -->
<section class="section featured-section" id="products">
    <div class="container">
        <div class="reference-title">
            <span>منتجاتنا</span>
            <h2>منتجات مميزة</h2>
        </div>
        <div class="featured-grid">
            <?php
            $products = array(
                array('الصمامات الصناعية',         'photo-0', 'Industrial Valves'),
                array('الأنابيب وخطوط البخار',     'photo-1', 'Pipes & Steam Lines'),
                array('الوصلات والملحقات',         'photo-2', 'Fittings & Accessories'),
                array('تجهيزات أنظمة البخار',       'photo-3', 'Steam Systems'),
                array('تجهيزات الستانلس ستيل',     'photo-4', 'Stainless Steel'),
                array('ملحقات القياس والتحكم',     'photo-5', 'Measurement & Control'),
                array('صمامات التحكم',             'photo-0', 'Control Valves'),
                array('وصلات وفلنجات',             'photo-2', 'Couplings & Flanges')
            );
            foreach ($products as $p) {
                echo '<a class="featured-card" href="#contact">
                    <div class="product-photo ' . $p[1] . '"></div>
                    <div class="featured-caption">
                        <small>' . $p[2] . '</small>
                        <h3>' . $p[0] . '</h3>
                    </div>
                </a>';
            }
            ?>
        </div>
    </div>
</section>

<!-- CATEGORIES -->
<section class="section categories-section" id="categories">
    <div class="container">
        <div class="reference-title">
            <span>اطلع على مجموعتنا</span>
            <h2>تصنيفاتنا</h2>
        </div>
        <div class="category-grid">
            <?php
            $cats = array(
                array('الصمامات الصناعية',       'photo-0'),
                array('الأنابيب وخطوط البخار',   'photo-1'),
                array('الوصلات والملحقات',       'photo-2'),
                array('تجهيزات أنظمة البخار',     'photo-3'),
                array('تجهيزات الستانلس ستيل',   'photo-4'),
                array('ملحقات القياس والتحكم',   'photo-5')
            );
            foreach ($cats as $c) {
                echo '<a class="category-tile" href="#contact">
                    <div class="product-photo ' . $c[1] . '"></div>
                    <h3>' . $c[0] . '</h3>
                </a>';
            }
            ?>
        </div>
    </div>
</section>

<!-- APPLICATIONS -->
<section class="section applications" id="about">
    <div class="container">
        <div class="reference-title">
            <span>تصفّح حلولنا</span>
            <h2>تجهيزات لمجالات صناعية متنوعة</h2>
        </div>
        <div class="reference-applications">
            <?php
            $apps = array(
                array('الصناعات الغذائية',  'تجهيزات خطوط المعالجة والتسخين.'),
                array('الصناعات الدوائية',  'مكونات تناسب متطلبات العملية الصناعية.'),
                array('الأجبان والألبان',   'تجهيزات الستانلس وخطوط الخدمة.'),
                array('خطوط البخار',        'تغذية وتوزيع البخار وعودة المكثفات.'),
                array('صناعة الخبز',        'تجهيزات البخار والتسخين في الإنتاج.'),
                array('أنظمة التسخين والتبريد', 'أنابيب وصمامات وملحقات ربط.')
            );
            foreach ($apps as $a) {
                echo '<article>
                    <h3>' . $a[0] . '</h3>
                    <p>' . $a[1] . '</p>
                </article>';
            }
            ?>
        </div>
    </div>
</section>

<!-- SOLUTIONS -->
<section class="reference-solutions">
    <div class="container">
        <div class="reference-title">
            <span>مجموعة حريتاني</span>
            <h2>حلولنا الصناعية</h2>
        </div>
        <div class="application-grid">
            <?php
            $sols = array(
                array('تجهيزات البخار',     'مكونات متكاملة لخطوط البخار والتغذية وعودة المكثفات.'),
                array('الصمامات والوصلات',  'تجهيزات الربط والعزل والتحكم المناسبة لتطبيقك الصناعي.'),
                array('الستانلس ستيل',      'أنابيب ووصلات لتطبيقات المعامل الغذائية والدوائية.')
            );
            foreach ($sols as $s) {
                echo '<article>
                    <span>SOLUTIONS</span>
                    <h3>' . $s[0] . '</h3>
                    <p>' . $s[1] . '</p>
                </article>';
            }
            ?>
        </div>
    </div>
</section>

<!-- CONTACT -->
<section class="home-contact" id="contact">
    <div class="container">
        <div class="reference-title">
            <span>على تواصل</span>
            <h2>نقطة البداية لحلّك</h2>
        </div>
        <div class="contact-grid">
            <div>
                <div class="contact-item">
                    <span>الهاتف</span>
                    <a href="tel:+963944044252">+963 944 044 252</a>
                </div>
                <div class="contact-item">
                    <span>البريد الإلكتروني</span>
                    <a href="mailto:info@neumaticworld.com">info@neumaticworld.com</a>
                </div>
                <div class="contact-item">
                    <span>العنوان</span>
                    <p>سوريا — حلب، السليمانية، شارع الحاج حبيب. أول تقاطع على اليسار، 50 متراً على اليمين.</p>
                </div>
            </div>
            <form class="contact-form" action="" method="post">
                <h2>أرسل استفسارك</h2>
                <div class="form-row">
                    <label>الاسم
                        <input type="text" name="name" required>
                    </label>
                    <label>الهاتف
                        <input type="tel" name="phone">
                    </label>
                </div>
                <label>البريد الإلكتروني
                    <input type="email" name="email" required>
                </label>
                <label>رسالتك
                    <textarea name="message" rows="4" required></textarea>
                </label>
                <button class="button" type="submit"><span>←</span> إرسال</button>
                <p class="form-note">مراسلة مباشرة: info@neumaticworld.com</p>
            </form>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="cta">
    <div class="container">
        <div>
            <span class="eyebrow">استشارة مجانية</span>
            <h2>بحاجة إلى استشارة؟</h2>
            <p>فريقنا جاهز للإجابة على استفساراتك.</p>
        </div>
        <a class="button light" href="tel:+963944044252"><span>←</span> استفسر الآن</a>
    </div>
</section>

</main>

<?php get_footer(); ?>