<?php
/**
 * HRITANI GROUP — Professional B2B Steam Equipment Theme
 * Rebuilt from reference design (original.css by hritani-steam-world)
 */
if (!defined('ABSPATH')) exit;

// قائمة WP
function hritani_register_menus() {
    register_nav_menus(array(
        'primary' => 'القائمة الرئيسية'
    ));
}
add_action('after_setup_theme', 'hritani_register_menus');

function hritani_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array('search-form'));
}
add_action('after_setup_theme', 'hritani_setup');

// CSS
function hritani_styles() {
    $uri = get_template_directory_uri();
    wp_enqueue_style('hritani-original', $uri . '/assets/original.css', array(), '1.1.0');
    wp_enqueue_style('hritani-bridge', $uri . '/assets/original-bridge.css', array(), '1.1.0');
    wp_enqueue_style('hritani-main', get_stylesheet_uri(), array(), '2.0.0');
}
add_action('wp_enqueue_scripts', 'hritani_styles');

// عدد الكلمات
function hritani_excerpt($text) {
    $text = strip_tags($text);
    $words = explode(' ', $text);
    return implode(' ', array_slice($words, 0, 12));
}

// المحتوى الثنائي
define('HRI_PHONE', '+963 944 044 252');
define('HRI_EMAIL', 'info@neumaticworld.com');
define('HRI_ADDRESS', 'سوريا — حلب، السليمانية، شارع الحاج حبيب');
define('HRI_HOURS', 'السبت — الخميس: 8:00 — 17:00');

// قائمة WP مع fallback
function hritani_nav() {
    if (has_nav_menu('primary')) {
        wp_nav_menu(array(
            'theme_location' => 'primary',
            'container' => false,
            'menu_class' => '',
            'fallback_cb' => 'hritani_nav_fallback'
        ));
    } else {
        hritani_nav_fallback();
    }
}
function hritani_nav_fallback() {
    echo '<a href="' . home_url('/') . '">الرئيسية</a>
          <a href="#products">منتجاتنا</a>
          <a href="#about">من نحن</a>
          <a href="#contact">تواصل معنا</a>';
}